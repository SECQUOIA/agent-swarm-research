Globally certified measurement selection with correlated errors

Build from this directory with pdfLaTeX, BibTeX and latexmk:
latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build main.tex

The computational supplement is distributed separately.
