# Limits and Guarantees for Quadratic Intersection Cuts

Anonymous manuscript source package. The PDF and electronic evidence
companion are supplied separately.

Build from this directory with a standard TeX Live installation:

    latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build main.tex

All manuscript inputs use relative paths. The package includes references.bib
and the compiled main.bbl. No research notes, literature folder, solver,
external data, or machine-specific path is needed to build the paper.

The optional source check uses only the Python standard library:

    python3 verification/check_document.py
