try:
    from gdplib._version import __version__
except ImportError:
    __version__ = "unknown"

import gdplib.mod_hens
import gdplib.modprodnet
import gdplib.biofuel
import gdplib.positioning
import gdplib.spectralog
import gdplib.stranded_gas  # Requires logical expression system
import gdplib.gdp_col
import gdplib.hda
import gdplib.kaibel
import gdplib.methanol
import gdplib.batch_processing
import gdplib.jobshop
import gdplib.disease_model
import gdplib.med_term_purchasing
import gdplib.syngas
import gdplib.water_network
import gdplib.ex1_linan_2023
import gdplib.small_batch
import gdplib.cstr
import gdplib.reverse_electrodialysis
import gdplib.multiperiod_blending
import gdplib.grid
import gdplib.pandemic
