"""
Comprehensive test coverage for GDPlib models.

This module provides complete testing of all GDPlib models for:
1. Import capability
2. Model construction and execution
3. Coverage statistics and reporting
"""

import pytest
import importlib
import sys
import os

# Add the gdplib directory to the path for testing
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from build_model_test_utils import (  # noqa: E402
    get_required_build_model_parameters,
    is_missing_external_solver_error,
)


class TestComprehensiveCoverage:
    """Comprehensive tests for all GDPlib models ensuring importability and runnability."""

    # Complete list of all GDPlib modules
    ALL_GDPLIB_MODULES = [
        "batch_processing",
        "biofuel",
        "cstr",
        "disease_model",
        "ex1_linan_2023",
        "gdp_col",
        "grid",
        "hda",
        "jobshop",
        "kaibel",
        "med_term_purchasing",
        "methanol",
        "mod_hens",
        "modprodnet",
        "positioning",
        "reverse_electrodialysis",
        "small_batch",
        "spectralog",
        "stranded_gas",
        "syngas",
        "water_network",
        "multiperiod_blending",
        "pandemic",
    ]

    def test_coverage_statistics_report(self):
        """Generate and display comprehensive coverage statistics."""
        print("\n" + "=" * 80)
        print("GDPlib Comprehensive Test Coverage Report")
        print("=" * 80)

        # Test import status for all modules
        import_results = {}
        build_model_results = {}
        execution_results = {}
        unexpected_execution_failures = {}

        for module_name in self.ALL_GDPLIB_MODULES:
            # Test import
            try:
                module = importlib.import_module(f"gdplib.{module_name}")
                import_results[module_name] = "✅ SUCCESS"
            except Exception as e:
                import_results[module_name] = f"❌ FAILED: {str(e)}"
                continue

            # Test build_model availability
            if hasattr(module, "build_model"):
                build_model_results[module_name] = "✅ AVAILABLE"
                build_func = getattr(module, "build_model")
                required_params = get_required_build_model_parameters(build_func)
                if required_params:
                    execution_results[module_name] = (
                        f"REQUIRES_PARAMETERS: {', '.join(required_params)}"
                    )
                    continue

                # Test build_model execution
                try:
                    model = build_func()
                    if model is not None:
                        execution_results[module_name] = "✅ RUNNABLE"
                    else:
                        execution_results[module_name] = "⚠️  RETURNS_NULL"
                except Exception as e:
                    # Handle solver dependency issues gracefully
                    if is_missing_external_solver_error(e):
                        execution_results[module_name] = (
                            f"⚠️  REQUIRES_SOLVER: {str(e).split(':')[0] if ':' in str(e) else 'External solver'}"
                        )
                    else:
                        execution_results[module_name] = (
                            f"❌ EXECUTION_FAILED: {str(e)[:50]}..."
                        )
                        unexpected_execution_failures[module_name] = str(e)
            else:
                build_model_results[module_name] = "❌ MISSING"
                execution_results[module_name] = "N/A"

        # Print summary statistics
        total_modules = len(self.ALL_GDPLIB_MODULES)
        successful_imports = len(
            [v for v in import_results.values() if v == "✅ SUCCESS"]
        )
        available_build_models = len(
            [v for v in build_model_results.values() if v == "✅ AVAILABLE"]
        )
        runnable_models = len(
            [v for v in execution_results.values() if v == "✅ RUNNABLE"]
        )

        print("\nModule Import Statistics:")
        print(f"  Total Modules: {total_modules}")
        print(
            f"  Successful Imports: {successful_imports}/{total_modules} ({successful_imports/total_modules*100:.1f}%)"
        )
        print(
            f"  Available build_model: {available_build_models}/{total_modules} ({available_build_models/total_modules*100:.1f}%)"
        )
        print(
            f"  Runnable Models: {runnable_models}/{total_modules} ({runnable_models/total_modules*100:.1f}%)"
        )

        print("\nDetailed Results:")
        print(f"{'Module':<25} {'Import':<15} {'build_model':<15} {'Execution':<20}")
        print("-" * 80)

        for module_name in sorted(self.ALL_GDPLIB_MODULES):
            import_status = import_results.get(module_name, "UNKNOWN")
            build_status = build_model_results.get(module_name, "N/A")
            exec_status = execution_results.get(module_name, "N/A")

            print(
                f"{module_name:<25} {import_status:<15} {build_status:<15} {exec_status:<20}"
            )

        # Assert that we have good coverage
        assert (
            not unexpected_execution_failures
        ), "Unexpected build_model failures: " + "; ".join(
            f"{module_name}: {error}"
            for module_name, error in sorted(unexpected_execution_failures.items())
        )
        assert (
            successful_imports >= total_modules * 0.8
        ), f"Less than 80% of modules importable: {successful_imports}/{total_modules}"
        assert (
            runnable_models >= available_build_models * 0.7
        ), f"Less than 70% of available models are runnable: {runnable_models}/{available_build_models}"

    @pytest.mark.parametrize("module_name", ALL_GDPLIB_MODULES)
    def test_module_import_comprehensive(self, module_name):
        """Test that each module can be imported without errors."""
        try:
            module = importlib.import_module(f"gdplib.{module_name}")
            assert module is not None, f"Module {module_name} imported as None"
        except ImportError as e:
            pytest.fail(f"Failed to import {module_name}: {e}")
        except Exception as e:
            pytest.fail(f"Unexpected error importing {module_name}: {e}")

    @pytest.mark.parametrize("module_name", ALL_GDPLIB_MODULES)
    def test_build_model_exists_and_callable(self, module_name):
        """Test that build_model exists and is callable for each module."""
        try:
            module = importlib.import_module(f"gdplib.{module_name}")

            # Check if build_model exists
            assert hasattr(
                module, "build_model"
            ), f"Module {module_name} missing build_model function"

            # Check if it's callable
            build_func = getattr(module, "build_model")
            assert callable(build_func), f"{module_name}.build_model is not callable"

        except ImportError:
            pytest.skip(f"Module {module_name} cannot be imported")

    @pytest.mark.parametrize("module_name", ALL_GDPLIB_MODULES)
    def test_model_construction_and_execution(self, module_name):
        """Test that build_model can be executed successfully for each module."""
        try:
            module = importlib.import_module(f"gdplib.{module_name}")

            if not hasattr(module, "build_model"):
                pytest.skip(f"Module {module_name} has no build_model function")

            build_func = getattr(module, "build_model")

            required_params = get_required_build_model_parameters(build_func)
            if required_params:
                pytest.skip(
                    f"{module_name}.build_model requires parameters: "
                    f"{', '.join(required_params)}"
                )

            # Try to build the model
            try:
                model = build_func()
                assert model is not None, f"{module_name}.build_model() returned None"

                # Verify it's a Pyomo model
                assert hasattr(
                    model, "component_objects"
                ), f"{module_name} model is not a Pyomo model"

                # Check that model has some components
                components = list(model.component_objects())
                assert len(components) > 0, f"{module_name} model has no components"

            except Exception as e:
                # Handle solver dependency issues gracefully
                if is_missing_external_solver_error(e):
                    pytest.skip(
                        f"{module_name} requires external solver: {str(e)[:100]}"
                    )
                else:
                    pytest.fail(f"{module_name}.build_model failed: {e}")

        except ImportError:
            pytest.skip(f"Module {module_name} cannot be imported")

    def test_pyomo_dependencies_available(self):
        """Test that all required Pyomo dependencies are available."""
        required_pyomo_modules = [
            "pyomo.environ",
            "pyomo.gdp",
            "pyomo.core",
            "pyomo.opt",
        ]

        for module_name in required_pyomo_modules:
            try:
                importlib.import_module(module_name)
            except ImportError:
                pytest.fail(f"Required Pyomo module {module_name} not available")

    def test_gdp_constructs_available(self):
        """Test that GDP-specific constructs are available."""
        try:
            from pyomo.gdp import Disjunct
            from pyomo.environ import ConcreteModel, Var

            # Test basic GDP model creation
            model = ConcreteModel()
            model.x = Var(bounds=(0, 10))
            model.d = Disjunct()

            # This should work without errors
            assert model is not None
            assert model.x is not None
            assert model.d is not None

        except ImportError as e:
            pytest.fail(f"GDP constructs not available: {e}")

    def test_external_dependencies_available(self):
        """Test that external dependencies are properly installed."""
        required_external_modules = [
            "pandas",
            "matplotlib",
            "scipy",
            "pint",
            "openpyxl",
        ]

        missing_modules = []
        for module_name in required_external_modules:
            try:
                importlib.import_module(module_name)
            except ImportError:
                missing_modules.append(module_name)

        if missing_modules:
            pytest.fail(f"Missing required external modules: {missing_modules}")

    def test_coverage_framework_available(self):
        """Test that coverage tools are available for CI/CD."""
        try:
            import coverage

            # Test that coverage can be initialized
            cov = coverage.Coverage()
            assert cov is not None

            print("Coverage framework is available and functional")

        except ImportError:
            pytest.skip("Coverage package not available")
