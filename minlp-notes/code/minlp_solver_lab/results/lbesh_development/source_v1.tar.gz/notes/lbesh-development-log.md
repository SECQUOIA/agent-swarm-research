# Convex GDP supporting-hyperplane development

Started 2026-09-19. Scope: develop and independently verify this topic for a
publication; do not write the paper. The prior method and benchmark notes are
historical evidence, not an accepted publication package.

## Decisions and acceptance criteria

1. Identify the contribution relative to perspective cuts, ESH, logic-based
   outer approximation, disjunctive cut strengthening, and conic GDP methods.
   A new acronym or an unsuccessful literature search does not establish
   novelty. Negative computational findings remain in the record.
2. State complete assumptions and proofs for all theoretical claims. Separate
   exact-arithmetic claims from numerical solver contracts and tolerance-based
   feasibility/optimality.
3. Repair extraction, separation, incumbent, and termination behavior before
   freezing experimental code. Unsupported inputs must be refused explicitly.
4. Predeclare controlled instances and held-out seeds. Compare cut policies
   within the same solver, and include established solvers and exact conic
   hulls where applicable. Report preprocessing, failures, timeouts, and paired
   results; independently validate original-model primal witnesses.
5. Have fresh agents review final theory, implementation, and experimental
   interpretation. Address findings and rerun affected targeted checks.
6. Produce a reproducible research package and a claim/evidence ledger. Judge
   publication readiness from the resulting evidence, not the initial plan.

## Work allocation

- Theory author: full convergence contracts, perspective-cut identity,
  fractional separation residuals, and correction of old proof statements.
- Implementation author: original `lbesh` package and contract regressions.
- Literature investigator: primary-source comparisons and claim boundaries.
- Instance author: deterministic nonquadratic GDP families and witnesses.
- Benchmark author: fresh-process harness, independent primal validation,
  raw records, and unbiased summaries.
- Conic baseline author: exact quadratic hull implementation and equivalence
  checks.
- Coordinator: environment/licensing, experiment scheduling, integration,
  result interpretation, and later independent-review assignments.

Authors are not the final independent reviewers of their own work.

## Resource and environment policy

The machine exposes 36 logical CPUs and about 30 GiB RAM. At the initial
inspection about 23 GiB was available; other work is running on the machine.
Use one solver thread per run, `OMP_NUM_THREADS=1`, `OPENBLAS_NUM_THREADS=1`,
and `MKL_NUM_THREADS=1`. Broad experiment batches initially use at most six
workers. Reassess available memory before large batches. Do not run repository
wide verification or inspect CI logs.

Use the existing solver-lab environment and committed `uv.lock`:

```sh
cd code/minlp_solver_lab
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 \
PATH=/home/sgusev/miniconda3/envs/solvers/bin:$PATH \
uv run --frozen --no-sync python -m lbesh_research.environment \
  --out results/lbesh_development/environment.json
```

Executed successfully: the direct Gurobi API and GAMS SHOT, SCIP, Gurobi,
and BARON solved their probe problems; Ipopt also solved its continuous probe.
The nonlinear probe has the known optimum `-log(2)` and all returned points
passed the explicit numerical feasibility/objective check. Dependency
versions, platform, executable paths, baseline commit, and lockfile hash are
recorded in the output. License credentials and identifiers are not recorded.

## Early findings

- LB-ESH's affine cuts are perspective outer-approximation cuts; their
  validity is not a new cut-family result.
- The old 27-instance benchmark has nonlinear disjunct rows in 18 instances,
  all quadratic. The new study must exercise nonquadratic disjunct rows.
- The historic scorer counts a below-consensus objective as solved. Correct
  scoring alone is insufficient: historic records do not retain independent
  original-model feasibility evidence.
- The old single-tree termination path can report infeasibility merely
  because no reduced NLP incumbent was obtained, and it does not enforce a
  closed gap before reporting optimality.
- The old review's suggested objective-error estimate from separate Slater
  points needs additional joint regularity; its restriction on subgradient
  choice in the radial separation argument is also too strong. The theory
  note will give proofs and counterexamples.

This log is an active development record. Completion and publication
readiness have not yet been established.

## Pilot protocol and review progress

The first pilot uses five small instances with seed 104729, the eight matched
LB-ESH/ECP configurations, GDPopt LOA, SHOT big-M/hull, and the applicable
quadratic conic baseline. Its command was:

```sh
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 \
PATH=/home/sgusev/miniconda3/envs/solvers/bin:$PATH \
uv run --frozen --no-sync python -m lbesh_research.benchmark \
  --instances lbesh.exp.small.s104729,lbesh.log.small.s104729,lbesh.reciprocal.small.s104729,lbesh.quadratic.small.s104729,lbesh.logsumexp.small.s104729 \
  --methods all --time-limit 30 --wall-limit 60 --threads 1 --parallel 4 \
  --out results/lbesh_development/pilot_small_v1.jsonl
```

All 40 LB-ESH/ECP runs passed the independent original-model feasibility and
numerical gap checks. These are development measurements, not final timing
evidence: code review was still active. The pilot exposed inconsistent hull
initializations in the GAMS adapter, tolerance mismatches, and weak SHOT hull
bounds when convexity was not recognized. These require separate handling;
interface failures are not evidence of an algorithmic advantage. The default
SHOT hull behavior is retained, and a distinct declared-convex hull baseline
is being evaluated only for analytically verified generated models.

The scale pilot uses the ten corresponding medium/large instances with the
same seed and eight core configurations, 60-second solver limits, 90-second
wall limits, one thread, four workers. Output:
`results/lbesh_development/pilot_scale_v1.jsonl`.

Independent mathematical review accepted the qualified theory after four
precision corrections. Independent implementation reviews found and prompted
repairs for fixed-variable mutation, disjunct-indicator hull semantics,
unsupported active components, and conditional objectives. Their notes
preserve the findings and tests; acceptance applies only to the documented
supported scope and never means exact numerical certification.

Review showed that all initial 42 generated instances have standard conic
representations. Before any performance evaluation of the additional family,
the design was extended by nine trigonometric allocation instances using
`(1-cos(1.5*z))/(1-cos(0.75))` on `0 <= z <= 1/1.1`. This function is
increasing and convex throughout the full declared domain. This exercises
smooth expression oracles for which the package supplies no standard cone
translation; no impossibility of a conic formulation is claimed. Existing
parameters and seeds are unchanged.

### Pre-freeze reference-pass deviation

The coordinator's authorization for the conic-reference agent ambiguously
said to solve all 42 roots while the intended timing was after review and
freeze. The agent ran those continuous reference solves before receiving the
hold clarification. This file is retained as
`results/lbesh_development/general_conic_roots.json`. The agent inspected
aggregate statuses/residuals, not held-out objective values, and reported no
parameter tuning. The original seed split is retained rather than selecting
replacement seeds. These are predeclared held-out algorithm experiments,
not a claim that every reference computation was blind. A frozen reference
rerun is required before final use.
